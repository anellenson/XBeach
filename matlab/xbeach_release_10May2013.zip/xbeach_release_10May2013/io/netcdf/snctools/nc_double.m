function nc_datatype = nc_double()
% NC_DOUBLE:  returns constant corresponding to NC_DOUBLE enumerated constant in netcdf.h
%
% USAGE:  nc_datatype = nc_double;
%

nc_datatype = 6;
return
